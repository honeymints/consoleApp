public class OliveOilDecorator extends SaladDecorator {
    public OliveOilDecorator(Salad salad){
        super(salad);
    }

    public String addOliveOil(){
        return "with olive oil for ";
    }

    @Override
    public String getSalad() {
        return super.getSalad() + addOliveOil();
    }

    @Override
    public int price() {
        return super.price() + 100;
    }
}
