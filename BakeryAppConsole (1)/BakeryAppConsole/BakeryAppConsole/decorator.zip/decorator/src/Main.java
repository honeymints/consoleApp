import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String customerName;
        System.out.println("Dear customer, input your name: ");
        customerName = scanner.next();

        customerChoice(customerName);
    }

    private static void customerChoice(String customerName) {
        Scanner scanner = new Scanner(System.in);

        int t;
        System.out.println("What do you want to do, " + customerName + "?" + "\n 1. Buy a bakery product " +
                "\n 2. Buy a salad \n 3. Buy a hot dish \n 4. Buy a confectionery item \n 0. Exit");
        t = scanner.nextInt();

        switch (t) {
            case 1 -> {
                System.out.println("""
                        Choose what do you want:\s
                         1. Bun - 100 KZT\s
                         2. Samsa - 120 KZT\s
                         3. Croissant - 120 KZT\s
                         0. return""");

                bakeryManagement(customerName);
            }
            case 2 -> {
                System.out.println("""
                        Choose what do you want:\s
                         1. Greek salad - 250 KZT\s
                         2. Olivier salad - 200 KZT\s
                         3. Caesar salad - 450 KZT\s
                         0. return""");

                saladManagement(customerName);
            }
            case 3 -> {
                System.out.println("""
                        Choose what do you want:\s
                         1. Borsch - 300 KZT\s
                         2. Pizza - 500 KZT\s
                         3. Bread - 20 KZT\s
                         0. return""");

                hotDishesManagement(customerName);
            }
            case 4 -> {
                System.out.println("""
                        Choose what do you want:\s
                         1. Tiramisu - 400 KZT\s
                         2. Napoleon cake - 500 KZT\s
                         3. Cheesecake - 480 KZT\s
                         0. return""");


                cakeManagement(customerName);
            }
            case 0 -> {
            }
        }
    }

    //AYAN

    private static void hotDishesManagement(String customerName) {
        Scanner scanner = new Scanner(System.in);
        int h = scanner.nextInt();
        switch (h) {
            case 1 -> borschDecor(customerName);
            case 2 -> pizzaDecor(customerName);
            case 3 -> breadDecor(customerName);
            case 0 -> customerChoice(customerName);
        }
    }

    private static void borschDecor(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What additional option do you want?:\s
                 1. Meat - 200 KZT\s
                 2. Spicy sauce - 100 KZT\s
                 3. Sour cream - 50 KZT\s
                 4. Cheese - 100 KZT\s
                 0. return""");

        int s = scanner.nextInt();
        switch (s) {
            case 1 -> {
                Hotdishes hotdishes=(new MeatDecor(new Borsch()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 2 -> {
                Hotdishes hotdishes=(new SpicyDecorator(new Borsch()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 3 -> {
                Hotdishes hotdishes=(new SourCreamDecorator(new Borsch()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 4 -> {
                Hotdishes hotdishes=(new Dcheese(new Borsch()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 0 -> hotDishesManagement(customerName);
        }
    }

    private static void pizzaDecor(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What additional option do you want?:\s
                 1. Meat - 200 KZT\s
                 2. Spicy sauce - 100 KZT\s
                 3. Sour cream - 50 KZT\s
                 4. Cheese - 100 KZT\s
                 0. return""");

        int s = scanner.nextInt();
        switch (s) {
            case 1 -> {
                Hotdishes hotdishes=(new MeatDecor(new Pizza()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 2 -> {
                Hotdishes hotdishes=(new SpicyDecorator(new Pizza()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 3 -> {
                Hotdishes hotdishes=(new SourCreamDecorator(new Pizza()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 4 -> {
                Hotdishes hotdishes=(new Dcheese(new Pizza()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 0 -> hotDishesManagement(customerName);
        }
    }

    private static void breadDecor(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What additional option do you want?:\s
                 1. Meat - 200 KZT\s
                 2. Spicy sauce - 100 KZT\s
                 3. Sour cream - 50 KZT\s
                 4. Cheese - 100 KZT\s
                 0. return""");

        int s = scanner.nextInt();
        switch (s) {
            case 1 -> {
                Hotdishes hotdishes=(new MeatDecor(new Bread()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 2 -> {
                Hotdishes hotdishes=(new SpicyDecorator(new Bread()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 3 -> {
                Hotdishes hotdishes=(new SourCreamDecorator(new Bread()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 4 -> {
                Hotdishes hotdishes=(new Dcheese(new Bread()));
                System.out.println(hotdishes.getDescription() + hotdishes.price()+ " KZT");
            }
            case 0 -> hotDishesManagement(customerName);
        }
    }

    // RASH
    private static void cakeManagement(String customerName) {
        Scanner scanner = new Scanner(System.in);

        int c = scanner.nextInt();
        switch (c) {
            case 1 -> tiramisuCream(customerName);
            case 2 -> napoleonCream(customerName);
            case 3 -> cheesecakeCream(customerName);
            case 0 -> customerChoice(customerName);
        }
    }

        private static void tiramisuCream(String customerName) {
        Scanner scanner = new Scanner(System.in);
        int temp;
        if(temp==null){

        }
        else{

        }
            System.out.println("How much servings do you want? Min - 1, Max - 4");
            int serv = scanner.nextInt();
            System.out.println("you have chosen " + serv + " servings");
        System.out.println("Do you want to add cream? \n 1. yes \n 2. no");
        int choice = scanner.nextInt();
    if (choice == 1){

        System.out.println("""
                What cream do you prefer?:\s
                 1. Chantilly cream - 130 KZT\s
                 2. Charlotte cream - 150 KZT\s
                 3. Protein cream - 70 KZT\s
                 0. return""");

        int t = scanner.nextInt();
        switch (t) {
            case 1 -> {
                Confectionery confectionery = new ChantillyCream(new Tiramisu());
                toppingChoice(confectionery);

                System.out.println("do you want to add another cream? \n 1. yes \n 2. no");
                temp=0;

                int adding = scanner.nextInt();
                if(adding == 1){
                    temp=1;
                    tiramisuCream(customerName);
                }
                else{
                    toppingChoice(confectionery);
                }
            }
            case 2 -> {
                Confectionery confectionery = new CharlotteCream(new Tiramisu());
                toppingChoice(confectionery);
            }
            case 3 -> {
                Confectionery confectionery = new ProteinCream(new Tiramisu());
                toppingChoice(confectionery);
            }
            case 0 -> cakeManagement(customerName);
        }
    } else {
        Confectionery confectionery = new Tiramisu();

        int sum=0;
        for(int i=0;i<serv;i++){
           sum+= confectionery.price();
        }
        System.out.println(confectionery.getDescription() + "in " + serv + " servings" + " for " + sum + " KZT");
    }



    }

    private static void napoleonCream(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What cream do you prefer?:\s
                 1. Chantilly cream - 130 KZT\s
                 2. Charlotte cream - 150 KZT\s
                 3. Protein cream - 70 KZT\s
                 0. return""");

        int t = scanner.nextInt();
        switch (t) {
            case 1 -> {
                Confectionery confectionery = new ChantillyCream(new NapoleonCake());
                toppingChoice(confectionery);
            }
            case 2 -> {
                Confectionery confectionery = new CharlotteCream(new NapoleonCake());
                toppingChoice(confectionery);
            }
            case 3 -> {
                Confectionery confectionery = new ProteinCream(new NapoleonCake());
                toppingChoice(confectionery);
            }
            case 0 -> cakeManagement(customerName);
        }
    }

    private static void cheesecakeCream(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What cream do you prefer?:\s
                 1. Chantilly cream - 130 KZT\s
                 2. Charlotte cream - 150 KZT\s
                 3. Protein cream - 70 KZT\s
                 0. return""");

        int t = scanner.nextInt();
        switch (t) {
            case 1 -> {
                Confectionery confectionery = new ChantillyCream(new Cheesecake());
                toppingChoice(confectionery);
            }
            case 2 -> {
                Confectionery confectionery = new CharlotteCream(new Cheesecake());
                toppingChoice(confectionery);
            }
            case 3 -> {
                Confectionery confectionery = new ProteinCream(new Cheesecake());
                toppingChoice(confectionery);
            }
            case 0 -> cakeManagement(customerName);
        }
    }

    private static void toppingChoice(Confectionery confectionery) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What topping do you prefer?:\s
                 1. Chocolate - 100 KZT\s
                 2. Gingerbread - 90 KZT\s
                 3. Mastic - 160 KZT""");

        int t = scanner.nextInt();
        switch (t) {
            case 1 -> {
                confectionery = new ChocolateTopper(confectionery);
                System.out.println(confectionery.getDescription() + confectionery.price() + " KZT");
            }
            case 2 -> {
                confectionery = new GingerbreadToppers(confectionery);
                System.out.println(confectionery.getDescription() + confectionery.price() + " KZT");
            }
            case 3 -> {
                confectionery = new MasticTopper(confectionery);
                System.out.println(confectionery.getDescription() + confectionery.price() + " KZT");
            }

        }
    }

    // DANA

    private static void saladManagement(String customerName) {
        Scanner scanner = new Scanner(System.in);
        int s = scanner.nextInt();
        switch (s) {
            case 1 -> greekDressing(customerName);
            case 2 -> olivierDressing(customerName);
            case 3 -> caesarDressing(customerName);
            case 0 -> customerChoice(customerName);
        }
    }

    private static void greekDressing(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What dressing do you prefer?:\s
                 1. Mayonnaise - 50 KZT\s
                 2. Olive oil - 100 KZT\s
                 3. Balsamic vinegar - 70 KZT\s
                 0. return""");

        int s = scanner.nextInt();
        switch (s) {
            case 1 -> {
                Salad salad = new MayoDecorator(new GreekSalad());
                System.out.println(salad.getSalad() + salad.price() + " KZT");
            }
            case 2 -> {
                Salad salad = new OliveOilDecorator(new GreekSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 3 -> {
                Salad salad = new BalsamicVinegarDressing(new GreekSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 0 -> saladManagement(customerName);
        }
    }

    private static void olivierDressing(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What dressing do you prefer?:\s
                 1. Mayonnaise - 50 KZT\s
                 2. Olive oil - 100 KZT\s
                 3. Balsamic vinegar - 70 KZT\s
                 0. return""");

        int s = scanner.nextInt();
        switch (s) {
            case 1 -> {
                Salad salad = new MayoDecorator(new OlivierSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 2 -> {
                Salad salad = new OliveOilDecorator(new OlivierSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 3 -> {
                Salad salad = new BalsamicVinegarDressing(new OlivierSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 0 -> saladManagement(customerName);
        }
    }

    private static void caesarDressing(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What dressing do you prefer?:\s
                 1. Mayonnaise - 50 KZT\s
                 2. Olive oil - 100 KZT\s
                 3. Balsamic vinegar - 70 KZT\s
                 0. return""");

        int s = scanner.nextInt();
        switch (s) {
            case 1 -> {
                Salad salad = new MayoDecorator(new CaesarSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 2 -> {
                Salad salad = new OliveOilDecorator(new CaesarSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 3 -> {
                Salad salad = new BalsamicVinegarDressing(new CaesarSalad());
                System.out.println(salad.getSalad() + salad.price()+ " KZT");
            }
            case 0 -> saladManagement(customerName);
        }
    }

    //ARUZHAN

    private static void bakeryManagement(String customerName) {
        Scanner scanner = new Scanner(System.in);
        int b = scanner.nextInt();
        switch (b) {
            case 1 -> bunFillings(customerName);
            case 2 -> samsaFillings(customerName);
            case 3 -> croissantFillings(customerName);
            case 0 -> customerChoice(customerName);
        }
    }

    private static void croissantFillings(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What filling do you prefer?:\s
                 1. Meat - 150 KZT\s
                 2. Cheese - 100 KZT\s
                 3. Cabbage - 100 KZT\s
                 0. return""");

        int b = scanner.nextInt();
        switch (b) {
            case 1 -> {
                Bakery bakery=new MeatDecorator(new Croissant());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 2 -> {
                Bakery bakery=new CheeseDecorator(new Croissant());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 3 -> {
                Bakery bakery=new CabbageDecorator(new Croissant());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 0 -> bakeryManagement(customerName);
        }
    }

    private static void samsaFillings(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What filling do you prefer?:\s
                 1. Meat - 150 KZT\s
                 2. Cheese - 100 KZT\s
                 3. Cabbage - 100 KZT\s
                 0. return""");
        int b = scanner.nextInt();
        switch (b) {
            case 1 -> {
                Bakery bakery=new MeatDecorator(new Samsa());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 2 -> {
                Bakery bakery=new CheeseDecorator(new Samsa());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 3 -> {
                Bakery bakery=new CabbageDecorator(new Samsa());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 0 -> bakeryManagement(customerName);
        }
    }

    private static void bunFillings(String customerName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                What filling do you prefer?:\s
                 1. Meat - 150 KZT\s
                 2. Cheese - 100 KZT\s
                 3. Cabbage - 100 KZT\s
                 0. return""");
        int b = scanner.nextInt();
        switch (b) {
            case 1 -> {
                Bakery bakery=new MeatDecorator(new Bun());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 2 -> {
                Bakery bakery=new CheeseDecorator(new Bun());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 3 -> {
                Bakery bakery=new CabbageDecorator(new Bun());
                System.out.println(bakery.getDescription() + bakery.price()+ " KZT");
            }
            case 0 -> bakeryManagement(customerName);
        }
    }
}




