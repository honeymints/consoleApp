public interface Salad {
    public String getSalad();
    public int price();

}
