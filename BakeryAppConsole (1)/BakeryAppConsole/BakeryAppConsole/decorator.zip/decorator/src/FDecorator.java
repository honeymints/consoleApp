public class FDecorator implements Hotdishes {
    Hotdishes hotdishes;
      public FDecorator(Hotdishes hotdishes){
          this.hotdishes=hotdishes;
      }
    @Override
    public String getDescription() {
        return hotdishes.getDescription();
    }

    @Override
    public int price() {
        return hotdishes.price();
    }
}
