public class NapoleonCake implements Confectionery {
    @Override
    public String getDescription() {
        return "You bought napoleon cake ";
    }

    @Override
    public int price() {
        return 500;
    }

}
