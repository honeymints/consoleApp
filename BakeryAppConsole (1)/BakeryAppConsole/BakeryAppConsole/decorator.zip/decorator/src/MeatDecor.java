public class MeatDecor extends FDecorator {
    public MeatDecor(Hotdishes hotdishes) {
        super(hotdishes);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with meat for ";
    }

    @Override
    public int price() {
        return super.price() + 200;
    }
}
