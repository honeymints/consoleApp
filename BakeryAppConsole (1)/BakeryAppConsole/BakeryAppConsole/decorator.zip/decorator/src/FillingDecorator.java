public class FillingDecorator implements Bakery{
    Bakery bakery;
      public FillingDecorator(Bakery bakery){
          this.bakery=bakery;
      }
    @Override
    public String getDescription() {
        return bakery.getDescription();
    }

    @Override
    public int price() {
        return bakery.price();
    }
}
