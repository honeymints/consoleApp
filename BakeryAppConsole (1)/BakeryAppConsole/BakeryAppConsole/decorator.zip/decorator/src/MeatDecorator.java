public class MeatDecorator extends FillingDecorator{
    public MeatDecorator(Bakery bakery) {
        super(bakery);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "with meat for ";
    }

    @Override
    public int price() {
        return super.price() + 150;
    }
}
