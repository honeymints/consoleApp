public class GreekSalad implements Salad{
    @Override
    public String getSalad() {
        return "You bought greek salad ";
    }

    @Override
    public int price() {
        return 250;
    }
}
