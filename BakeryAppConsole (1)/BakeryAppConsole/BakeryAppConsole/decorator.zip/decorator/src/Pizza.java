public class Pizza implements Hotdishes {
    @Override
    public String getDescription() {
        return "You bought pizza";
    }

    @Override
    public int price() {
        return 500;
    }
}
