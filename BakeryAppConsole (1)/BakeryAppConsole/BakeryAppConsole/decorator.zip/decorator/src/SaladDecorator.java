public class SaladDecorator implements Salad{
    Salad salad;

    public SaladDecorator(Salad salad){
        this.salad = salad;
    }
    @Override
    public String getSalad() {
        return salad.getSalad();
    }

    @Override
    public int price() {
        return salad.price();
    }
}
