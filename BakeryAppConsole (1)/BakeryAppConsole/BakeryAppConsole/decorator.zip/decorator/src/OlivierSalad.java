public class OlivierSalad implements Salad{
    @Override
    public String getSalad() {
        return "You bought olivier salad ";
    }

    @Override
    public int price() {
        return 200;
    }
}
