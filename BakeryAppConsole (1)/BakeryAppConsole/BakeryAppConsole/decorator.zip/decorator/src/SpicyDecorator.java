public class SpicyDecorator extends FDecorator {
    public SpicyDecorator(Hotdishes hotdishes) {
        super(hotdishes);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "with cabbage for ";
    }

    @Override
    public int price() {
        return super.price() + 100;
    }
}
