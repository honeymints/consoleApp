public class Croissant implements Bakery{
    @Override
    public String getDescription() {
        return "You bought croissant ";
    }

    @Override
    public int price() {
        return 120;
    }
}
