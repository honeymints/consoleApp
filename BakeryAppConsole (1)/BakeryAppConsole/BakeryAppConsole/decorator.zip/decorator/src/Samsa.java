public class Samsa implements Bakery{
    @Override
    public String getDescription() {
        return "You bought samsa ";
    }

    @Override
    public int price() {
        return 120;
    }
}
