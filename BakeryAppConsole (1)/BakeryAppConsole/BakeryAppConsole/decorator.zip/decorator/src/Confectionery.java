public interface Confectionery {
    public String getDescription();
    public int price();
}
