public class CheeseDecorator extends FillingDecorator{
    public CheeseDecorator(Bakery bakery) {
        super(bakery);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "with cheese for ";
    }

    @Override
    public int price() {
        return super.price() + 100;
    }
}
