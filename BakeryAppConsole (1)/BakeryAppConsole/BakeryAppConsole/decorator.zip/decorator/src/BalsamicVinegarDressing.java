public class BalsamicVinegarDressing extends SaladDecorator{

    public BalsamicVinegarDressing(Salad salad) {
        super(salad);
    }

    public String addBalsamicVinegar(){
        return "with balsamic vinegar for ";
    }

    @Override
    public String getSalad() {
        return super.getSalad() + addBalsamicVinegar();
    }

    @Override
    public int price() {
        return super.price() + 70;
    }
}
