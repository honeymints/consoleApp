public class CabbageDecorator extends FillingDecorator{
    public CabbageDecorator(Bakery bakery) {
        super(bakery);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "with cabbage for ";
    }

    @Override
    public int price() {
        return super.price() + 100;
    }
}
