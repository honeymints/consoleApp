public class CaesarSalad implements Salad{
    @Override
    public String getSalad() {
        return "You bought caesar salad ";
    }

    @Override
    public int price() {
        return 450;
    }
}
