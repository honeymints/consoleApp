public class Borsch implements Hotdishes {
    @Override
    public String getDescription() {
        return "You bought borsch";
    }

    @Override
    public int price() {
        return 300;
    }
}
