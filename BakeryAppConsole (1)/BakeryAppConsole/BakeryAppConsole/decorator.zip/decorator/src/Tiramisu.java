public class Tiramisu implements Confectionery {
    @Override
    public String getDescription() {
        return "You bought tiramisu ";
    }

    @Override
    public int price() {
        return 400;
    }
}
