public class Cheesecake implements Confectionery {
    @Override
    public String getDescription() {
        return "You bought cheesecake ";
    }

    @Override
    public int price() {
        return 480;
    }
}
