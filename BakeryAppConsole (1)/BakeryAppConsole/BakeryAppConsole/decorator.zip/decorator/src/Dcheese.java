public class Dcheese extends FDecorator {
    public Dcheese(Hotdishes hotdishes) {
        super(hotdishes);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with cheese for ";
    }

    @Override
    public int price() {
        return super.price() + 100;
    }
}
