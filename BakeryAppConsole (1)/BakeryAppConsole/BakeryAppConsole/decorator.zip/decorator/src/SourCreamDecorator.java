public class SourCreamDecorator extends FDecorator {
    public SourCreamDecorator(Hotdishes hotdishes) {
        super(hotdishes);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "with SourCream for ";
    }

    @Override
    public int price() {
        return super.price() + 50;
    }
}
