public interface Bakery {
    public String getDescription();
    public int price();
}
