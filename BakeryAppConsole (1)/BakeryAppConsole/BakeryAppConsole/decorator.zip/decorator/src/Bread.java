public class Bread implements Hotdishes {
    @Override
    public String getDescription() {
        return "You bought bread ";
    }

    @Override
    public int price() {
        return 20;
    }
}
