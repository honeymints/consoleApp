public class MayoDecorator extends SaladDecorator {
    public MayoDecorator(Salad salad) {
        super(salad);
    }

    public String addMayo(){
        return "with mayonnaise for ";
    }

    @Override
    public String getSalad() {
        return super.getSalad() + addMayo();
    }

    @Override
    public int price() {
        return super.price() + 50;
    }
}
