public interface Hotdishes {
    public String getDescription();
    public int price();
}
